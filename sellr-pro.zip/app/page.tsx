import Form from "@/components/Form";

export default function Home() {
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: 40 }}>
      <h1 style={{ fontSize: 42 }}>Sellr.ai</h1>
      <p>Generate product pages that convert.</p>
      <Form />
    </main>
  );
}