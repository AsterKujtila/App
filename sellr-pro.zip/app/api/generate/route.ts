import { NextResponse } from "next/server";
import { client } from "@/lib/ai";

export async function POST(req: Request) {
  const { product } = await req.json();
  const prompt = `Write a high converting product page for ${product}`;
  const res = await client.messages.create({
    model: "claude-3-haiku-20240307",
    max_tokens: 300,
    messages: [{ role: "user", content: prompt }]
  });
  return NextResponse.json({ output: res.content[0]?.text });
}