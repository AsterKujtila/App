"use client";
import { useState } from "react";

export default function Form() {
  const [product, setProduct] = useState("");
  const [result, setResult] = useState("");

  const generate = async () => {
    const res = await fetch("/api/generate", {
      method: "POST",
      body: JSON.stringify({ product })
    });
    const data = await res.json();
    setResult(data.output || data.error);
  };

  return (
    <div>
      <input placeholder="Product" onChange={e => setProduct(e.target.value)} />
      <button onClick={generate}>Generate</button>
      <pre>{result}</pre>
    </div>
  );
}