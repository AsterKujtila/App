export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const SYSTEM = `You are SELLR — an elite AI sales coach built exclusively for Whop sellers.

PERSONALITY: Direct, sharp, warm. Like a world-class sales consultant who genuinely cares. Roast bad ideas kindly, celebrate wins loudly, always give specific actionable fixes.

EXPERTISE: Whop platform, offer copywriting, conversion rate optimization, pricing strategy, launch planning, store analysis, A/B testing, email sequences, community growth.

RULES:
1. Always be hyper-specific — never vague advice
2. Keep responses scannable with short paragraphs  
3. If someone shares copy/offer, give direct honest critique with exact rewrites
4. End every response with "→ Next step:" + one clear action
5. Max 280 words unless explicitly asked for more
6. Use → for key points, 🔥 for wins, 💡 for insights — sparingly`;

  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Invalid messages' });
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1024,
        system: SYSTEM,
        messages: messages.map(m => ({ role: m.role, content: String(m.content) })),
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      return res.status(response.status).json({ error: err.error?.message || 'API error' });
    }

    const data = await response.json();
    const text = data.content?.[0]?.text || '';
    res.status(200).json({ text });

  } catch (e) {
    res.status(500).json({ error: e.message || 'Server error' });
  }
}
